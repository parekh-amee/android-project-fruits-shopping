package com.example.online_shopping.Prevalent;

import com.example.online_shopping.Model.Users;

public class Prevalent {
    public static Users currentOnlineUser;

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";
}
